// MODULE
var bankApp = angular.module('bankApp', ['ngRoute']);

bankApp.config(function($routeProvider) {
	// -- specify routes or hash values and patterns
	$routeProvider
	
	.when('/',{
		templateUrl: 'pages/home.html',
		controller: 'homeController'
	})
	
	.when('/chat', {
		templateUrl: 'pages/chat.html',
		controller: 'chatController'
	})
});

// CONTROLLERS
bankApp.controller('homeController', ['$scope', function ($scope) {
	// in case needed for cleanup code
}]);

bankApp.controller('chatController', ['$scope', function ($scope) {
}]);